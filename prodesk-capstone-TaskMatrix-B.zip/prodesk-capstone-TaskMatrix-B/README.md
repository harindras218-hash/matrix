# prodesk-capstone-TaskMatrix (Sprint 3, Track B)

Express + MongoDB (Mongoose) + JWT REST API, React (Vite) client, Stripe Checkout (test mode).

## Run in VS Code (two terminals)
**Terminal 1 (API)**
```
cd server
npm install
copy .env.example to .env  (fill MONGO_URI, JWT_SECRET, STRIPE_SECRET_KEY=sk_test_...)
npm run dev
```
**Terminal 2 (client)**
```
cd client
npm install
npm run dev     # http://localhost:5173
```
Stripe test card: 4242 4242 4242 4242, any future expiry, any CVC.

## Endpoints (all /api/tasks/* need `Authorization: Bearer <jwt>`)
| Method | Path | Notes |
|---|---|---|
| POST | /api/auth/register, /login | returns JWT `{userId}` |
| POST | /api/tasks | authorId set from JWT |
| GET | /api/tasks | only caller's tasks |
| PUT | /api/tasks/:id | 403 if task.authorId != JWT userId |
| DELETE | /api/tasks/:id | 403 if task.authorId != JWT userId |
| POST | /api/payments/checkout | returns Stripe Checkout URL |
| GET | /api/payments/session/:id | verifies payment on /success |
