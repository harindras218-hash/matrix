import { Routes, Route, Navigate } from "react-router-dom";
import Auth from "./Auth.jsx";
import Tasks from "./Tasks.jsx";
import Success from "./Success.jsx";
import { getToken } from "./api.js";

const Private = ({ children }) => (getToken() ? children : <Navigate to="/login" replace />);

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Auth />} />
      <Route path="/" element={<Private><Tasks /></Private>} />
      <Route path="/success" element={<Private><Success /></Private>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
