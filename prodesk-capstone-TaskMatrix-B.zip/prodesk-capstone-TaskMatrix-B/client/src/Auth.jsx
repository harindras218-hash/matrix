import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "./api.js";

export default function Auth() {
  const nav = useNavigate();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    try {
      const data = await api(`/auth/${mode}`, { method: "POST", body: form });
      localStorage.setItem("token", data.token);
      nav("/");
    } catch (e2) { setErr(e2.message); }
  }

  return (
    <main className="center">
      <form className="modal" onSubmit={submit}>
        <h3>TaskMatrix</h3>
        {mode === "register" && <label>Name<input value={form.name} onChange={set("name")} /></label>}
        <label>Email<input value={form.email} onChange={set("email")} /></label>
        <label>Password<input type="password" value={form.password} onChange={set("password")} /></label>
        {err && <p className="err">{err}</p>}
        <div className="actions">
          <button type="button" className="ghost" onClick={() => { setErr(""); setMode(mode === "login" ? "register" : "login"); }}>
            {mode === "login" ? "Create account" : "Have an account?"}
          </button>
          <button>{mode === "login" ? "Log in" : "Sign up"}</button>
        </div>
      </form>
    </main>
  );
}
