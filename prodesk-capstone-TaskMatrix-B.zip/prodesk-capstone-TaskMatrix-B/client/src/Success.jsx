import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { api } from "./api.js";

export default function Success() {
  const [params] = useSearchParams();
  const [info, setInfo] = useState(null);
  const [err, setErr] = useState("");

  useEffect(() => {
    const id = params.get("session_id");
    if (id) api(`/payments/session/${id}`).then(setInfo).catch((e) => setErr(e.message));
  }, [params]);

  return (
    <main className="center">
      <div className="modal">
        <h3>Payment successful</h3>
        {info && <p>Status: <b>{info.status}</b> ({(info.amount / 100).toFixed(2)} {info.currency?.toUpperCase()})</p>}
        {err && <p className="err">{err}</p>}
        <Link to="/">Back to dashboard</Link>
      </div>
    </main>
  );
}
