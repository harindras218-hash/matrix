import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "./api.js";

const empty = { title: "", description: "", status: "todo", priority: "medium", dueDate: "" };

export default function Tasks() {
  const nav = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState(empty);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    api("/tasks").then(setTasks).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError("");
    try {
      if (editingId) {
        const updated = await api(`/tasks/${editingId}`, { method: "PUT", body: form });
        setTasks((prev) => prev.map((t) => (t._id === editingId ? updated : t)));
      } else {
        const created = await api("/tasks", { method: "POST", body: form });
        setTasks((prev) => [created, ...prev]);
      }
      setForm(empty); setEditingId(null);
    } catch (e2) { setError(e2.message); }
  }

  function startEdit(t) {
    setEditingId(t._id);
    setForm({ title: t.title, description: t.description, status: t.status, priority: t.priority, dueDate: t.dueDate });
  }

  // Optimistic delete: remove from UI immediately, roll back if the API call fails
  async function remove(id) {
    if (!window.confirm("Delete this task permanently?")) return;
    const snapshot = tasks;
    setTasks((prev) => prev.filter((t) => t._id !== id));
    try { await api(`/tasks/${id}`, { method: "DELETE" }); }
    catch (e) { setTasks(snapshot); setError(`Delete failed, restored: ${e.message}`); }
  }

  async function upgrade() {
    try { const { url } = await api("/payments/checkout", { method: "POST" }); window.location.href = url; }
    catch (e) { setError(e.message); }
  }

  return (
    <main className="wrap">
      <header>
        <h2>TaskMatrix</h2>
        <div>
          <button className="pay" onClick={upgrade}>Upgrade to Pro ($9 test)</button>{" "}
          <button className="ghost" onClick={() => { localStorage.removeItem("token"); nav("/login"); }}>Logout</button>
        </div>
      </header>

      <form className="card form" onSubmit={submit}>
        <h3>{editingId ? "Edit task" : "New task"}</h3>
        <input placeholder="Title" value={form.title} onChange={set("title")} />
        <input placeholder="Description" value={form.description} onChange={set("description")} />
        <div className="row">
          <select value={form.status} onChange={set("status")}><option>todo</option><option>in-progress</option><option>done</option></select>
          <select value={form.priority} onChange={set("priority")}><option>low</option><option>medium</option><option>high</option></select>
          <input type="date" value={form.dueDate} onChange={set("dueDate")} />
        </div>
        <div className="actions">
          {editingId && <button type="button" className="ghost" onClick={() => { setEditingId(null); setForm(empty); }}>Cancel</button>}
          <button>{editingId ? "Update" : "Add task"}</button>
        </div>
      </form>

      {error && <p className="err">{error}</p>}
      {loading ? <p>Loading...</p> : tasks.length === 0 ? <p>No tasks yet.</p> : (
        <table>
          <thead><tr><th>Title</th><th>Status</th><th>Priority</th><th>Due</th><th></th></tr></thead>
          <tbody>
            {tasks.map((t) => (
              <tr key={t._id}>
                <td><b>{t.title}</b><div className="muted">{t.description}</div></td>
                <td>{t.status}</td><td>{t.priority}</td><td>{t.dueDate || "-"}</td>
                <td>
                  <button className="ghost" onClick={() => startEdit(t)}>Edit</button>{" "}
                  <button className="danger" onClick={() => remove(t._id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}
