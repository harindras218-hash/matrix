const router = require("express").Router();
const Stripe = require("stripe");
const auth = require("../middleware/auth");

// Stripe TEST mode only: use a key starting with sk_test_
router.post("/checkout", auth, async (req, res) => {
  try {
    if (!process.env.STRIPE_SECRET_KEY) return res.status(500).json({ message: "STRIPE_SECRET_KEY missing" });
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{
        quantity: 1,
        price_data: { currency: "usd", unit_amount: 900, product_data: { name: "TaskMatrix Pro (test)" } },
      }],
      client_reference_id: req.user.userId,
      success_url: `${process.env.CLIENT_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.CLIENT_URL}/`,
    });
    res.json({ url: session.url });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Success page calls this to confirm payment status
router.get("/session/:id", auth, async (req, res) => {
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const s = await stripe.checkout.sessions.retrieve(req.params.id);
    if (s.client_reference_id !== req.user.userId) return res.status(403).json({ message: "Forbidden" });
    res.json({ status: s.payment_status, amount: s.amount_total, currency: s.currency });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
