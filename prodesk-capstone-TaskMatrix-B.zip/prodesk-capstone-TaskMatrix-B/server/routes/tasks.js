const router = require("express").Router();
const mongoose = require("mongoose");
const Task = require("../models/Task");
const auth = require("../middleware/auth");

router.use(auth); // every task route is JWT-protected

const FIELDS = ["title", "description", "status", "priority", "dueDate"];
const pick = (body) => Object.fromEntries(FIELDS.filter((k) => body[k] !== undefined).map((k) => [k, body[k]]));

// Ownership guard: authorId (document) must equal userId (decoded JWT)
async function loadOwned(req, res, next) {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid task id" });
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ message: "Task not found" });
  if (task.authorId.toString() !== req.user.userId)
    return res.status(403).json({ message: "Forbidden: you do not own this task" });
  req.task = task;
  next();
}

router.post("/", async (req, res) => {
  try {
    const data = pick(req.body);
    if (!data.title || !data.title.trim()) return res.status(400).json({ message: "Title is required" });
    const task = await Task.create({ ...data, authorId: req.user.userId }); // never trust client authorId
    res.status(201).json(task);
  } catch (e) { res.status(400).json({ message: e.message }); }
});

router.get("/", async (req, res) => {
  const tasks = await Task.find({ authorId: req.user.userId }).sort({ createdAt: -1 });
  res.json(tasks);
});

router.put("/:id", loadOwned, async (req, res) => {
  try {
    Object.assign(req.task, pick(req.body));
    await req.task.save();
    res.json(req.task);
  } catch (e) { res.status(400).json({ message: e.message }); }
});

router.delete("/:id", loadOwned, async (req, res) => {
  await req.task.deleteOne();
  res.json({ message: "Deleted", id: req.params.id });
});

module.exports = router;
